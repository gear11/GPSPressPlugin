=== GPSPress ===
Contributors: Gear11
Tags: gps, location, map
Requires at least: 3.8
Tested up to: 3.8
License: GPL V2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds time and location information to WordPress posts to support discovery
by date and place.

. With GPSPress, your readers can browse
your posts by time and location.  Includes a widget for displaying your posts
as markers in Google Maps.

== Installation ==
TBD

== Frequently Asked Questions ==
None yet

== Changelog ==
2014/1/19 Initial version